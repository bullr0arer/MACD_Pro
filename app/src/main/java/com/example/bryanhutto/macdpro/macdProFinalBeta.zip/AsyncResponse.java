package com.example.bryanhutto.macdpro;

/**
 * Created by bryanhutto on 4/14/15.
 */
public interface AsyncResponse {
        void processFinish(DataHolder dataHolder);
}
